Param
(
    [Parameter(Mandatory=$True)]
    [String]
    $ServicePrincipalDisplayName,

    [Parameter(Mandatory=$True)]
    [String]
    $ServicePrincipalHomePage,

    [Parameter(Mandatory=$True)]
    [String]
    $ServicePrincipalIdentifierUri,

    [Parameter(Mandatory=$True)]
    [SecureString]
    $ServicePrincipalSecurePassword
)

$networkCredential = New-Object System.Net.NetworkCredential
$networkCredential.SecurePassword = $ServicePrincipalSecurePassword

$ErrorActionPreference = 'Stop'

$azureAdApplication = New-AzureRmADApplication `
    -DisplayName $ServicePrincipalDisplayName `
    -HomePage $ServicePrincipalHomePage `
    -IdentifierUris $ServicePrincipalIdentifierUri `
    -Password $networkCredential.Password

New-AzureRmADServicePrincipal -ApplicationId $azureAdApplication.ApplicationId

# New-AzureRmRoleAssignment fails immediately after New-AzureRmADServicePrincipal is run, because it cannot yet find the application.
Start-Sleep -s 10

New-AzureRmRoleAssignment -RoleDefinitionName Owner -ServicePrincipalName $azureAdApplication.ApplicationId

$subscription = (Get-AzureRmContext).Subscription

Write-Host "ServicePrincipalId: $($azureAdApplication.ApplicationId)"
Write-Host "ServicePrincipalTenantId: $($subscription.TenantId)"
Write-Host "ServicePrincipalSubscriptionId: $($subscription.SubscriptionId)"
