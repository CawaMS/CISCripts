Param
(
    [Parameter(Mandatory=$True)]
    [String]
    $ServicePrincipalPassword
)

$servicePrincipalSecurePassword = ConvertTo-SecureString $ServicePrincipalPassword -AsPlainText -Force
$servicePrincipalCredentials = New-Object System.Management.Automation.PSCredential ($env:ServicePrincipalId, $servicePrincipalSecurePassword)
    
# Add-AzureAccount will succeed (as a no-op) if the account was previously added.
Add-AzureRmAccount -Credential $servicePrincipalCredentials -ServicePrincipal -Tenant $env:ServicePrincipalTenantId
Select-AzureRmSubscription -SubscriptionId $env:ServicePrincipalSubscriptionId -TenantId $env:ServicePrincipalTenantId

$resourceGroup = Get-AzureRmResourceGroup | Where-Object { $_.ResourceGroupName -eq $env:ServiceFabricClusterResourceGroupName }
if ($resourceGroup -ne $null)
{
    Remove-AzureRmResourceGroup -Name $env:ServiceFabricClusterResourceGroupName -Force
}
