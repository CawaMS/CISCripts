Param
(
    [Parameter(Mandatory=$True)]
    [String]
    $ServicePrincipalPassword,
    
    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricClusterAdminPassword
)

$ErrorActionPreference = 'Stop'

# Authenticate as Service Principal
$servicePrincipalSecurePassword = ConvertTo-SecureString $ServicePrincipalPassword -AsPlainText -Force
$servicePrincipalCredentials = New-Object System.Management.Automation.PSCredential ($env:ServicePrincipalId, $servicePrincipalSecurePassword)
$secureServiceFabricClusterAdminPassword = ConvertTo-SecureString $ServiceFabricClusterAdminPassword -AsPlainText -Force

Add-AzureRmAccount -Credential $servicePrincipalCredentials -ServicePrincipal -Tenant $env:ServicePrincipalTenantId
Select-AzureRmSubscription -SubscriptionId $env:ServicePrincipalSubscriptionId -TenantId $env:ServicePrincipalTenantId

# Provision Cluster
New-AzureRmResourceGroup -Name $env:ServiceFabricClusterResourceGroupName -Location $env:ServiceFabricClusterLocation
New-AzureRmResourceGroupDeployment `
    -Force `
    -ResourceGroupName $env:ServiceFabricClusterResourceGroupName `
    -TemplateFile $env:ServiceFabricClusterResourceGroupTemplateFilePath `
    -clusterName $env:ServiceFabricClusterName `
    -clusterLocation $env:ServiceFabricClusterLocation `
    -computeLocation $env:ServiceFabricClusterLocation `
    -vmStorageAccountName $env:ServiceFabricClusterStorageAccountName `
    -adminPassword $secureServiceFabricClusterAdminPassword `
    -dnsName $env:ServiceFabricClusterDnsName `
    -certificateThumbprint $env:ServiceFabricCertificateThumbprint `
    -sourceVaultValue $env:ServiceFabricKeyVaultId `
    -certificateUrlValue $env:ServiceFabricCertificateSecretId

# Retrieve Connection Endpoint
$clusterResource = Get-AzureRmResource -ResourceType Microsoft.ServiceFabric/clusters -ResourceGroupName $env:ServiceFabricClusterResourceGroupName -ResourceName $env:ServiceFabricClusterName
$managementUri = [System.Uri]$clusterResource.Properties.managementEndpoint
$uriBuilder = New-Object System.UriBuilder($managementUri)
$uriBuilder.Scheme = $null
$uriBuilder.Port = 19000
$connectionEndpoint = $uriBuilder.Uri

$clusterConnectionParameters = @{
    "ConnectionEndpoint" = "$connectionEndpoint";
    "X509Credential" = $True;
    "ServerCertThumbprint" = "${env:ServiceFabricCertificateThumbprint}";
    "FindType" = "FindByThumbprint";
    "FindValue" = "${env:ServiceFabricCertificateThumbprint}";
    "StoreLocation" = "LocalMachine";
    "StoreName" = "My";
}

[void](Connect-ServiceFabricCluster @clusterConnectionParameters)

& $env:ServiceFabricDeploymentScriptPath `
    -PublishProfileFile "${env:ServiceFabricPublishProfilePath}" `
    -ApplicationPackagePath "${env:ServiceFabricApplicationProjectPath}\pkg\${env:BuildConfiguration}" `
    -UseExistingClusterConnection
