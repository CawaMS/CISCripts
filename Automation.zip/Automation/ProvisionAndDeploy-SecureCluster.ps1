Param
(
    [Parameter(Mandatory=$True)]
    [String]
    $ServicePrincipalPassword,
    
    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricClusterAdminPassword
)

$ErrorActionPreference = 'Stop'

# Authenticate as Service Principal
$servicePrincipalSecurePassword = ConvertTo-SecureString $ServicePrincipalPassword -AsPlainText -Force
$servicePrincipalCredentials = New-Object System.Management.Automation.PSCredential ($env:ServicePrincipalId, $servicePrincipalSecurePassword)

Add-AzureRmAccount -Credential $servicePrincipalCredentials -ServicePrincipal -Tenant $env:ServicePrincipalTenantId
Select-AzureRmSubscription -SubscriptionId $env:ServicePrincipalSubscriptionId -TenantId $env:ServicePrincipalTenantId

# Provision Cluster
New-AzureRmResourceGroup -Name $env:ServiceFabricClusterResourceGroupName -Location $env:ServiceFabricClusterLocation
$templateParameters = @{
    "clusterName" = $env:ServiceFabricClusterName;
    "clusterLocation" = $env:ServiceFabricClusterLocation;
    "adminPassword" = $ServiceFabricClusterAdminPassword;
    "certificateThumbprint" = $env:ServiceFabricCertificateThumbprint;
    "sourceVaultValue" = $env:ServiceFabricKeyVaultId;
    "certificateUrlValue" = $env:ServiceFabricCertificateSecretId;
}

New-AzureRmResourceGroupDeployment `
    -Force `
    -ResourceGroupName $env:ServiceFabricClusterResourceGroupName `
    -TemplateFile $env:ServiceFabricClusterResourceGroupTemplateFilePath `
    -TemplateParameterObject $templateParameters


# Retrieve Connection Endpoint
$clusterResource = Get-AzureRmResource -ResourceType Microsoft.ServiceFabric/clusters -ResourceGroupName $env:ServiceFabricClusterResourceGroupName -ResourceName $env:ServiceFabricClusterName
$managementUri = [System.Uri]$clusterResource.Properties.managementEndpoint
$uriBuilder = New-Object System.UriBuilder($managementUri)
$uriBuilder.Scheme = $null
$uriBuilder.Port = 19000
$connectionEndpoint = $uriBuilder.Uri

$clusterConnectionParameters = @{
    "ConnectionEndpoint" = "$connectionEndpoint";
    "X509Credential" = $True;
    "ServerCertThumbprint" = "${env:ServiceFabricCertificateThumbprint}";
    "FindType" = "FindByThumbprint";
    "FindValue" = "${env:ServiceFabricCertificateThumbprint}";
    "StoreLocation" = "LocalMachine";
    "StoreName" = "My";
}

$maxConnectionAttempts = 20
$connectionAttemptInterval = 30 # seconds

for ($i = 0; $i -lt $maxConnectionAttempts; $i++)
{
    try
    {
        [void](Connect-ServiceFabricCluster @clusterConnectionParameters)
        break
    }
    catch [System.Fabric.FabricException]
    {
        $message = "Connection attempt $($i + 1) of $maxConnectionAttempts failed."
        if ($i -lt $maxConnectionAttempts - 1)
        {
            Write-Host "$message Retrying..."
            
            Start-Sleep -Seconds $connectionAttemptInterval
        }
        else
        {
            Write-Host $message

            throw
        }
    }
}

& $env:ServiceFabricDeploymentScriptPath `
    -PublishProfileFile "${env:ServiceFabricPublishProfilePath}" `
    -ApplicationPackagePath "${env:ServiceFabricApplicationProjectPath}\pkg\${env:BuildConfiguration}" `
    -OverwriteBehavior Never `
    -UseExistingClusterConnection
