Param
(
    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricKeyVaultLocation,

    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricCertificateSecretName,

    [Parameter(Mandatory=$True)]
    [SecureString]
    $ServiceFabricSecureCertificatePassword,

    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricKeyVaultResourceGroupName,

    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricKeyVaultName,
    
    [Parameter(Mandatory=$True)]
    [String]
    $ServiceFabricPfxFileOutputPath
)

$ErrorActionPreference = 'Stop'

# Create Certificate
$cert = New-SelfSignedCertificate `
    -CertStoreLocation "Cert:\LocalMachine\My" `
    -DnsName $ServiceFabricCertificateSecretName

# Export Certificate as PFX
if (Test-Path $ServiceFabricPfxFileOutputPath)
{
    Remove-Item $ServiceFabricPfxFileOutputPath -Force
}

Export-PfxCertificate -Cert $cert -FilePath $ServiceFabricPfxFileOutputPath -Password $ServiceFabricSecureCertificatePassword

# Create resource Group
if (Get-AzureRmResourceGroup | ? ResourceGroupName -eq $ServiceFabricKeyVaultResourceGroupName)
{
    Remove-AzureRmResourceGroup -Name $ServiceFabricKeyVaultResourceGroupName -Force
}

New-AzureRmResourceGroup -Name $ServiceFabricKeyVaultResourceGroupName -Location $ServiceFabricKeyVaultLocation -Verbose

# Create Key Vault
Write-Host "Creating vault $ServiceFabricKeyVaultName in $ServiceFabricKeyVaultLocation (resource group $ServiceFabricKeyVaultResourceGroupName)"
$keyVault = New-AzureRmKeyVault -VaultName $ServiceFabricKeyVaultName -ResourceGroupName $ServiceFabricKeyVaultResourceGroupName -Location $ServiceFabricKeyVaultLocation -EnabledForDeployment -Verbose

# Create Certificate
$certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 $ServiceFabricPfxFileOutputPath, $ServiceFabricSecureCertificatePassword

# Convert Certificate to a secure string
$bytes = [System.IO.File]::ReadAllBytes($ServiceFabricPfxFileOutputPath)
$base64 = [System.Convert]::ToBase64String($bytes)

$networkCredential = New-Object System.Net.NetworkCredential
$networkCredential.SecurePassword = $ServiceFabricSecureCertificatePassword

$jsonBlob = @{
    data = $base64
    dataType = 'pfx'
    password = $networkCredential.Password
} | ConvertTo-Json

$jsonBlobBytes = [System.Text.Encoding]::UTF8.GetBytes($jsonBlob)
$secretContent = [System.Convert]::ToBase64String($jsonBlobBytes)
$secretValue = ConvertTo-SecureString -String $secretContent -AsPlainText -Force

# Register certificate as a secret in the key vault.
Write-Host "Writing secret $ServiceFabricCertificateSecretName to vault $ServiceFabricKeyVaultName"
Set-AzureKeyVaultSecret -VaultName $ServiceFabricKeyVaultName -Name $ServiceFabricCertificateSecretName -SecretValue $secretValue -Verbose
$certificateSecret = Get-AzureKeyVaultSecret -VaultName $ServiceFabricKeyVaultName -Name $ServiceFabricCertificateSecretName -IncludeVersions

Write-Host "ServiceFabricCertificateThumbprint: $($certificate.Thumbprint)"
Write-Host "ServiceFabricKeyVaultId: $($keyVault.ResourceId)"
Write-Host "ServiceFabricCertificateSecretId: $($certificateSecret.Id)"
